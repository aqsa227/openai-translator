function NotFound() {
  return (
    <div className="w-full max-w-full p-4 m-0 mb-12">
      <h1>404 NotFound</h1>
    </div>
  );
}

export default NotFound;
